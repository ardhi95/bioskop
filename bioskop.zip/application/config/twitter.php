<?php
/**
 * twconnect library configuration
 */

$config = array(
  'consumer_key'    => 'aRTCslE1J9oasSPpAvaSdtZGm',
  'consumer_secret' => 'OnPoMcYJWMtAlWSp9RUQA8thlnwStl78HjXgL3aMYvWOZuoryi',
  'oauth_callback'      => '/Twtest/callback' // Default callback application path
);

?>